'use strict';

/* Draft based ONLY on the first request supplied by Gabriel on 2026-09-23.
 * One natural-person subscriber, one insured person, one classic loan.
 * No HTTP call, no tariff, no endpoint/authentication assumptions.
 * Intended for a future server-side adapter; not loaded in the HTML preview.
 */
const riskFields = Object.freeze([
  'smoker', 'abroadTravel', 'aerialOrLandSport', 'highMileage',
  'workAtHeight', 'heavyLoadHandling'
]);
const coverageCodes = Object.freeze(['Deces', 'PTIA', 'ITT', 'IPT']);

function buildRequest(input = {}, configuration = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)
    || !configuration || typeof configuration !== 'object' || Array.isArray(configuration))
    return {valid:false, errors:[{field:'request', message:'Une requête et une configuration structurées sont nécessaires.'}]};
  const errors = [];
  const person = input.person || {}, loan = input.loan || {}, address = input.address || {};
  const text = (value, path) => {
    if (typeof value !== 'string' || !value.trim() || /[{}<>\r\n]/.test(value)) {
      errors.push({field:path, message:'Valeur à renseigner avec le référentiel APRIL applicable.'});
      return '';
    }
    return value.trim();
  };
  const numeric = (value, path, min, max = Infinity, integer = false) => {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value)))
      errors.push({field:path, message:'Valeur numérique hors format.'});
    return value;
  };
  const date = (value, path) => {
    const parsed = typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(value+'T00:00:00Z') : null;
    if (!parsed || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0,10) !== value) {
      errors.push({field:path, message:'Date réelle attendue au format AAAA-MM-JJ.'});
    }
    return value;
  };
  const effectiveDate = date(input.effectiveDate, 'effectiveDate');
  const birthDate = date(person.birthDate, 'person.birthDate');
  if (!errors.some(e => e.field === 'effectiveDate' || e.field === 'person.birthDate') && birthDate >= effectiveDate)
    errors.push({field:'person.birthDate', message:'La naissance doit précéder la prise d’effet.'});

  const postCode = text(address.postCode, 'address.postCode');
  if (!/^\d{5}$/.test(postCode)) errors.push({field:'address.postCode', message:'Ce brouillon prend en charge un code postal français de cinq chiffres.'});
  const email = text(input.email, 'email');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push({field:'email', message:'Adresse e-mail à vérifier.'});
  const insuredPerson = {
    $id:'i-1', title:text(person.title, 'person.title'), birthDate,
    professionalCategory:text(person.professionalCategory, 'person.professionalCategory'),
    profession:text(person.profession, 'person.profession')
  };
  for (const key of riskFields) {
    if (typeof person[key] !== 'boolean') errors.push({field:'person.'+key, message:'Une réponse explicite oui/non est nécessaire.'});
    insuredPerson[key] = person[key];
  }
  if (loan.loanType !== 'Classique') errors.push({field:'loan.loanType', message:'Seul le type Classique est décrit dans le flux de référence.'});
  const insuranceQuota = numeric(input.coveragePercentage, 'coveragePercentage', 0.01, 100);
  // Broker/product settings must come from trusted server configuration,
  // never from values supplied by the public form.
  const product = configuration.product || {};
  const commission = text(configuration.commission, 'configuration.commission');
  const productCode = text(product.productCode, 'configuration.product.productCode');
  const contributionType = text(product.contributionType, 'configuration.product.contributionType');
  if (productCode !== 'ADPGenerali' || contributionType !== 'variable')
    errors.push({field:'configuration.product', message:'Ce brouillon correspond uniquement à ADPGenerali / variable, selon le premier exemple fourni.'});
  const coverageSettings = product.coverages;
  if (!Array.isArray(coverageSettings) || coverageSettings.length !== 4 || !coverageCodes.every(code => coverageSettings.some(c => c?.guaranteeCode === code)))
    errors.push({field:'configuration.product.coverages', message:'Les quatre garanties distinctes du flux de référence doivent être configurées.'});
  const coverages = Array.isArray(coverageSettings) ? coverageSettings.map(c => {
    if (!c || !coverageCodes.includes(c.guaranteeCode)) { errors.push({field:'configuration.product.coverages',message:'Garantie absente du flux de référence.'}); return null; }
    const row = {loan:{$ref:'pr-1'}, guaranteeCode:c.guaranteeCode, coveragePercentage:insuranceQuota};
    if (c.guaranteeCode === 'ITT') {
      row.deductibleCode = text(c.deductibleCode, 'configuration.product.ITT.deductibleCode');
      row.levelCode = text(c.levelCode, 'configuration.product.ITT.levelCode');
    }
    if (c.guaranteeCode === 'IPT') {
      row.compensationMode = text(c.compensationMode, 'configuration.product.IPT.compensationMode');
      row.levelCode = text(c.levelCode, 'configuration.product.IPT.levelCode');
    }
    return row;
  }) : [];
  const request = {
    $type:'Emprunteur',
    properties:{
      addresses:[{$id:'adr-1', type:'Actuelle', postCode, city:text(address.city, 'address.city')}],
      projectType:text(input.projectType, 'projectType'), email, commission,
      moralSubscriber:false, effectiveDate
    },
    persons:[insuredPerson],
    loans:[{$id:'pr-1', loanType:'Classique',
      borrowedAmount:numeric(loan.borrowedAmount, 'loan.borrowedAmount', 0.01),
      loanDuration:numeric(loan.loanDuration, 'loan.loanDuration', 1, Infinity, true),
      interestRate:numeric(loan.interestRate, 'loan.interestRate', 0)
    }],
    products:[{$id:'p-1', productCode, contributionType,
      insured:{role:'AssurePrincipal', person:{$ref:'i-1'}}, coverages
    }]
  };
  return errors.length ? {valid:false, errors} : {valid:true, request};
}

module.exports = {buildRequest};
