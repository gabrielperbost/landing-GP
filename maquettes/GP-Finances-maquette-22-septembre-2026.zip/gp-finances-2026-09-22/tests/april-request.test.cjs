const {test}=require('node:test');
const assert=require('node:assert/strict');
const {buildRequest}=require('../integrations/april/build-request.cjs');
// Synthetic fixture; no supplied third-party email or contact details.
const input=()=>({
  address:{postCode:'38000',city:'GRENOBLE'},projectType:'ResidencePrincipale',email:'simulation@example.invalid',effectiveDate:'2026-10-01',
  person:{title:'Monsieur',birthDate:'1970-07-01',professionalCategory:'CadreAssimileCadre',profession:'AgentCommercial',smoker:false,abroadTravel:false,aerialOrLandSport:false,highMileage:false,workAtHeight:false,heavyLoadHandling:false},
  loan:{loanType:'Classique',borrowedAmount:250000,loanDuration:240,interestRate:1.9},coveragePercentage:100
});
const config=()=>({commission:'4010',product:{productCode:'ADPGenerali',contributionType:'variable',coverages:[
  {guaranteeCode:'Deces'},{guaranteeCode:'PTIA'},
  {guaranteeCode:'ITT',deductibleCode:'090',levelCode:'ConfortPlus'},
  {guaranteeCode:'IPT',compensationMode:'Capital',levelCode:'ConfortPlus'}
]}});
test('requête conforme à la structure du premier flux, références résolues',()=>{
 const r=buildRequest(input(),config());assert.equal(r.valid,true);const p=r.request;
 assert.equal(p.$type,'Emprunteur');assert.equal(p.products.length,1);assert.equal('product' in p,false);
 assert.equal(p.products[0].insured.person.$ref,p.persons[0].$id);
 for(const c of p.products[0].coverages)assert.equal(c.loan.$ref,p.loans[0].$id);
 assert.equal(p.products[0].coverages.find(c=>c.guaranteeCode==='ITT').deductibleCode,'090');
 assert.equal(p.properties.email,'simulation@example.invalid');
});
test('les risques absents ou textuels ne deviennent pas automatiquement faux',()=>{
 for(const value of [undefined,null,'false',0]){const i=input();i.person.highMileage=value;const r=buildRequest(i,config());assert.equal(r.valid,false);assert.ok(r.errors.some(e=>e.field==='person.highMileage'));assert.equal(r.request,undefined);}
});
test('date variable et dates inexistantes rejetées, année bissextile respectée',()=>{
 for(const d of ['{{dateEffet}}','*{{dateEffet}}*','2026-02-29','2026-04-31'])assert.equal(buildRequest({...input(),effectiveDate:d},config()).valid,false);
 assert.equal(buildRequest({...input(),effectiveDate:'2028-02-29'},config()).valid,true);
});
test('la commission ne provient pas du formulaire et reste requise',()=>{
 const i={...input(),commission:'9999',productCode:'ADPv4'};
 assert.equal(buildRequest(i,config()).request.properties.commission,'4010');
 const c=config();delete c.commission;assert.equal(buildRequest(i,c).valid,false);
});
test('pas de fusion automatique avec le second exemple',()=>{
 const c=config();c.product.productCode='ADPv4';c.product.contributionType='Variable';assert.equal(buildRequest(input(),c).valid,false);
 const d=config();d.product.coverages[0].guaranteeCode='DC';assert.equal(buildRequest(input(),d).valid,false);
});
test('montants, durée et quotité doivent être explicites et cohérents',()=>{
 for(const partial of [{borrowedAmount:0},{borrowedAmount:NaN},{loanDuration:0},{loanDuration:2.5},{interestRate:-1},{loanType:'Relais'}]){
  const i=input();i.loan={...i.loan,...partial};assert.equal(buildRequest(i,config()).valid,false);
 }
 for(const coveragePercentage of [0,101,undefined,'100'])assert.equal(buildRequest({...input(),coveragePercentage},config()).valid,false);
});
test('aucun tarif ou appel réseau fabriqué par le constructeur',()=>{
 const r=buildRequest(input(),config());assert.deepEqual(Object.keys(r).sort(),['request','valid']);
 assert.equal(JSON.stringify(r).includes('currentInsuranceMonthly'),false);
});
test('un corps JSON nul ou mal formé produit une validation, pas une exception serveur',()=>{
 for(const value of [null,[],true,12,'Emprunteur']){
  assert.equal(buildRequest(value,config()).valid,false);
  assert.equal(buildRequest(input(),value).valid,false);
 }
});
